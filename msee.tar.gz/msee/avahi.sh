avahi-browse -r -t _ni._tcp
