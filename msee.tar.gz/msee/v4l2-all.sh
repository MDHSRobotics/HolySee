#!/bin/sh

v4l2-ctl --all -d $1