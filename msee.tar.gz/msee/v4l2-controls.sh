#!/bin/sh

v4l2-ctl --list-ctrls -d $1