#!/bin/bash
# script to start msee

./MSee --gst-plugin-path=.
